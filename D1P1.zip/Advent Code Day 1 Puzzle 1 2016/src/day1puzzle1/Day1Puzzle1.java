package day1puzzle1;

import java.io.FileReader;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Day1Puzzle1 {
	
	static Scanner scan = new Scanner(System.in);
	static int startx = 0;
	static int starty = 0;
	static int destinationx;
	static int destinationy;
	static int curx = startx;
	static int cury = starty;
	static char facing = 'N';
	static int moveval;
	static char movedir;
	static String Instruction;
	static int difx;
	static int dify;
	static int totalblocks;
	static int loops;
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try (
				Scanner sc = new Scanner(
					new FileReader("C:\\Users\\darkl\\Desktop\\travelinput.txt"));	
						
				) {
			
					sc.useDelimiter(Pattern.compile("(, )|(\r\n)"));
					sc.useLocale(Locale.ENGLISH);
					
					while (sc.hasNext()) {
						loops++;
						Instruction = sc.next();
						movedir = Instruction.charAt(0);
						Instruction = Instruction.substring(1);
						moveval = Integer.parseInt(Instruction);
						
						if(facing == 'N')
						{
							System.out.println("Loop #: " + loops + ". Started facing North.");
							if(movedir == 'L')
							{
							
								curx -= moveval;
								facing = 'W';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								
								//return;
							}
							 
							else if(movedir == 'R')
							{
								curx += moveval;
								facing = 'E';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								
								//return;julo
							}
							
						}
						
						
						else if(facing == 'S')
						{
							System.out.println("Loop #: " + loops + ". Started facing South.");
							if(movedir == 'L')
							{
								curx += moveval;
								facing = 'E';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
							else if(movedir == 'R')
							{
								curx -= moveval;
								facing = 'W';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
						}
						
						else if(facing == 'E')
						{
							System.out.println("Loop #: " + loops + ". Started facing East.");
							if(movedir == 'L')
							{
								cury -= moveval;
								facing = 'N';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
							else if(movedir == 'R')
							{
								cury += moveval;
								facing = 'S';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
						}
						
						else 
						{
							System.out.println("Loop #: " + loops + ". Started facing West.");
							if(movedir == 'L')
							{
								cury += moveval;
								facing = 'S';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
							else if(movedir == 'R')
							{
								cury -= moveval;
								facing = 'N';
								System.out.println("Loop #: " + loops + ". " +Instruction + " Moved " + moveval + " blocks to the " + movedir + ". Now facing " + facing);
								//return;
							}
							
						}
						
					}
					
					destinationx = curx;
					destinationy = cury;
					System.out.println("The destination is at coordinates " + curx + "X and " + cury + "Y.");
					destinationx = Math.abs(destinationx);
					destinationy = Math.abs(destinationy);
					
					
					if(destinationx < startx)
					{
						startx -= destinationx;
						difx = startx;
					}
					
					else if(destinationx > startx)
					{
						destinationx -= startx;
						difx = destinationx;
					}
					
					if(destinationy < starty)
					{
						starty -= destinationy;
						dify = starty;	
					}
					
					else if(destinationy > starty)
					{
						destinationy -= starty;
						dify = destinationy;
					}
					
					difx += dify;
					totalblocks = difx;
					
					System.out.println("The destination is " + totalblocks + " blocks away!");
		}
					catch (IOException e) {
						
						e.printStackTrace();
					}
			
		scan.close();
		
		

	}

}
